import { MenuItem, BrandConcept, BranchLocation, Publication } from '../types.ts';

// Using our generated high-fidelity images
export const heroImages = {
  rider: '/src/assets/images/hero_delivery_rider_1791694950729.jpg',
  karahi: '/src/assets/images/food_karahi_bbq_spread_1791694963917.jpg',
  village: '/src/assets/images/village_buffet_heritage_1791694976718.jpg',
  fastfood: '/src/assets/images/fastfood_burger_pizza_1791694987491.jpg',
};

export const brandConcepts: BrandConcept[] = [
  {
    id: 'restaurant',
    name: 'Restaurant',
    subtitle: 'Casual & Fine Dining Experience',
    description: 'The flagship dining brand serving an eclectic fusion of authentic Pakistani specialties, continental sizzlers, steaks, and Chinese delicacies.',
    location: 'Mall Road & Liberty Market, Lahore',
    features: ['Signature Sizzlers', 'Desi Karahi & Handi', 'Family Private Lounges', 'Valet Parking'],
    image: heroImages.karahi,
    tag: 'Flagship Dine-In'
  },
  {
    id: 'village',
    name: 'Village',
    subtitle: 'The Legendary Live Cooking Buffet',
    description: 'Pakistan’s world-renowned open-air village buffet showcasing rustic live kitchens, freshly baked tandoori naans, clay pot slow-cooked hareesa, and traditional hospitality.',
    location: 'Gulberg III, Lahore & GT Road, Gujranwala',
    features: ['80+ Grand Buffet Dishes', 'Live Tandoor & Charcoal BBQ', 'Traditional Folk Ambience', 'Family Festivities'],
    image: heroImages.village,
    tag: 'Grand Buffet Heritage'
  },
  {
    id: 'express',
    name: 'Express',
    subtitle: 'Quick Service & Lightning Delivery',
    description: 'Designed for on-the-go cravings and rapid home delivery. Loaded gourmet burgers, golden crispy fried chicken, stone-baked pizzas, and value family boxes.',
    location: 'DHA, Bahria Town & Emporium Mall',
    features: ['30-Min Fast Delivery', 'Free Delivery in Lahore', 'Late Night Ordering', 'App Exclusive Deals'],
    image: heroImages.fastfood,
    tag: 'Fast Food & Delivery'
  }
];

export const menuItems: MenuItem[] = [
  {
    id: 'deal-1',
    name: 'Lahori Royal Feast Platter',
    category: 'deals',
    description: 'Half Chicken Karahi, 4pc Chicken Reshmi Kabab, 4pc Chicken Tikka Boti, 4 Roghani Naan, Fresh Salad & Mint Raita.',
    price: 3690,
    image: heroImages.karahi,
    serves: '3-4 Persons',
    badge: 'Best Seller',
    isSpicy: true,
    spiceLevel: 'Medium'
  },
  {
    id: 'deal-2',
    name: 'Express Fast Food Combo Box',
    category: 'deals',
    description: '2 Crispy Chicken Crunch Burgers, 4pc Crispy Wings, Large Loaded Crinkle Fries, and 2 Chilled Soft Drinks.',
    price: 1950,
    image: heroImages.fastfood,
    serves: '2 Persons',
    badge: 'Popular Deal',
    isSpicy: false,
    spiceLevel: 'Mild'
  },
  {
    id: 'deal-3',
    name: 'Village BBQ Party Platter',
    category: 'deals',
    description: 'Beef Seekh Kababs, Malai Boti, Kasturi Chicken Boti, Fish Tikka, Puri Parathas, Imli Chutney & Mint Raita.',
    price: 4490,
    image: heroImages.karahi,
    serves: '4-5 Persons',
    badge: 'Chef Special',
    isSpicy: true,
    spiceLevel: 'Medium'
  },
  {
    id: 'karahi-1',
    name: 'Special Desi Murgh Karahi',
    category: 'karahi',
    description: 'Tender chicken cooked on high flame in fresh tomatoes, ginger juliennes, green chillies, and freshly roasted black pepper.',
    price: 1850,
    image: heroImages.karahi,
    serves: '2-3 Persons',
    badge: 'Signature',
    isSpicy: true,
    spiceLevel: 'Medium'
  },
  {
    id: 'karahi-2',
    name: 'Mutton Shinwari Karahi',
    category: 'karahi',
    description: 'Traditional Pashtun style bone-in mutton cooked in rendered fat, tomatoes, rock salt and coarse black pepper with no extra spices.',
    price: 3450,
    image: heroImages.karahi,
    serves: '2-3 Persons',
    badge: 'Chef Special',
    isSpicy: false,
    spiceLevel: 'Mild'
  },
  {
    id: 'karahi-3',
    name: 'Murgh Makhni White Handi',
    category: 'karahi',
    description: 'Boneless chicken cubes simmered in creamy yogurt sauce, green cardamom, white pepper, and a rich dollop of dairy butter.',
    price: 2190,
    image: heroImages.karahi,
    serves: '2-3 Persons',
    isSpicy: false,
    spiceLevel: 'Mild'
  },
  {
    id: 'bbq-1',
    name: 'Chicken Reshmi Kabab (6 Pcs)',
    category: 'bbq',
    description: 'Minced chicken blended with fresh cream, mild green spices, and skewered over glowing charcoal embers.',
    price: 1390,
    image: heroImages.karahi,
    serves: '2 Persons',
    isSpicy: false,
    spiceLevel: 'Mild'
  },
  {
    id: 'bbq-2',
    name: 'Mutton Seekh Kabab (4 Pcs)',
    category: 'bbq',
    description: 'Hand-ground premium mutton minced with aromatic spices, smoked to juicy tenderness over charcoal.',
    price: 1890,
    image: heroImages.karahi,
    serves: '2 Persons',
    badge: 'Traditional',
    isSpicy: true,
    spiceLevel: 'Hot'
  },
  {
    id: 'bbq-3',
    name: 'Chicken Malai Boti Platter',
    category: 'bbq',
    description: 'Boneless chicken pieces marinated overnight in rich malai, cashew paste, and white pepper, grilled gently.',
    price: 1490,
    image: heroImages.karahi,
    serves: '2 Persons',
    isSpicy: false,
    spiceLevel: 'Mild'
  },
  {
    id: 'fastfood-1',
    name: 'The Big Boss Beef Cheeseburger',
    category: 'fastfood',
    description: 'Double 100% pure smashed beef patties, melted sharp cheddar, caramelized onions, house pickle relish & secret burger sauce on toasted brioche.',
    price: 1290,
    image: heroImages.fastfood,
    serves: '1 Person',
    badge: 'Top Rated',
    isSpicy: false,
    spiceLevel: 'Mild'
  },
  {
    id: 'fastfood-2',
    name: 'Crispy Zinger Crunch Burger',
    category: 'fastfood',
    description: 'Golden fried chicken breast fillet with spicy secret dredge, iceberg lettuce, and spicy jalapeño mayo.',
    price: 990,
    image: heroImages.fastfood,
    serves: '1 Person',
    isSpicy: true,
    spiceLevel: 'Medium'
  },
  {
    id: 'fastfood-3',
    name: 'Crispy Fried Chicken (5 Pcs Tender & Juicy)',
    category: 'fastfood',
    description: 'Fresh chicken marinated in 11 secret herbs and spices, pressure-fried to golden crispy perfection with garlic dip.',
    price: 1550,
    image: heroImages.fastfood,
    serves: '2 Persons',
    isSpicy: true,
    spiceLevel: 'Medium'
  },
  {
    id: 'pizza-1',
    name: 'Lahori Chicken Tikka Pizza',
    category: 'pizza',
    description: 'Wood-fired crust with spicy smoked chicken tikka chunks, mozzarella blend, red onions, bell peppers & crushed red pepper.',
    price: 1690,
    image: heroImages.fastfood,
    serves: 'Large (3-4 Persons)',
    badge: 'Local Favorite',
    isSpicy: true,
    spiceLevel: 'Medium'
  },
  {
    id: 'pizza-2',
    name: 'Fajita Sicilian Special Pizza',
    category: 'pizza',
    description: 'Spiced fajita chicken, mushrooms, black olives, sweet corn, and a layer of molten mozzarella with herb drizzle.',
    price: 1750,
    image: heroImages.fastfood,
    serves: 'Large (3-4 Persons)',
    isSpicy: false,
    spiceLevel: 'Mild'
  },
  {
    id: 'dessert-1',
    name: 'Traditional Shahi Kulfi Falooda',
    category: 'dessert',
    description: 'Handcrafted saffron pistachio kulfi served over chilled handmade vermicelli, sweet basil seeds & rose syrup.',
    price: 650,
    image: heroImages.village,
    serves: '1 Person',
    badge: 'Iconic Sweet'
  },
  {
    id: 'dessert-2',
    name: 'Hot Shahi Gulab Jamun (4 Pcs)',
    category: 'dessert',
    description: 'Golden fried khoya dumplings soaked in fragrant green cardamom sugar syrup, garnished with silver leaf and sliced almonds.',
    price: 490,
    image: heroImages.village,
    serves: '2 Persons'
  },
  {
    id: 'dessert-3',
    name: 'Fresh Mint Margarita Cooler',
    category: 'dessert',
    description: 'Fresh garden mint leaves crushed with lime juice, black rock salt, and ice-cold sparkling fizz.',
    price: 390,
    image: heroImages.karahi,
    serves: '1 Person'
  }
];

export const lahoreBranches: BranchLocation[] = [
  {
    id: 'b-1',
    name: 'Mall Road Flagship',
    city: 'Lahore',
    address: '48 The Mall, Near GPO, Shahrah-e-Quaid-e-Azam, Lahore',
    timing: '12:00 PM – 1:00 AM',
    phone: '+92 42 111 100 678',
    type: 'Dine-In, Takeaway & Delivery'
  },
  {
    id: 'b-2',
    name: 'Liberty Market Gulberg',
    city: 'Lahore',
    address: 'Commercial Zone, Liberty Market, Gulberg III, Lahore',
    timing: '12:00 PM – 2:00 AM',
    phone: '+92 42 111 100 678',
    type: 'Dine-In & Fast Delivery'
  },
  {
    id: 'b-3',
    name: 'The Village Lahore',
    city: 'Lahore',
    address: '103-B/2, M.M. Alam Road, Gulberg II, Lahore',
    timing: 'Lunch & Dinner Buffet: 1:00 PM – Midnight',
    phone: '+92 42 111 100 678',
    type: 'Grand Live Village Buffet'
  },
  {
    id: 'b-4',
    name: 'DHA Phase 5 Commercial',
    city: 'Lahore',
    address: 'Sector CCA, Phase 5 DHA, Lahore Cantt',
    timing: '12:00 PM – 3:00 AM',
    phone: '+92 42 111 100 678',
    type: 'Express Delivery Hub & Dining'
  },
  {
    id: 'b-5',
    name: 'Bahria Town Lahore',
    city: 'Lahore',
    address: 'Civic Centre, Sector C Commercial, Bahria Town, Lahore',
    timing: '12:00 PM – 2:00 AM',
    phone: '+92 42 111 100 678',
    type: 'Dine-In, Express Delivery'
  },
  {
    id: 'b-6',
    name: 'Emporium Mall Food Court',
    city: 'Lahore',
    address: 'Level 2 Food Court, Emporium Mall, Johar Town, Lahore',
    timing: '11:00 AM – 11:30 PM',
    phone: '+92 42 111 100 678',
    type: 'Express Food Court'
  }
];

export const publications: Publication[] = [
  {
    id: 'pub-1',
    title: 'The Masterclass of Pakistani Cookery',
    author: 'Executive Master Chefs',
    year: 'Best-Seller Edition',
    description: 'The definitive culinary encyclopedia documenting authentic regional cooking methods from Lahore, Peshawar, Sindh, and Punjab.',
    highlights: ['150+ Authentic Recipes', 'Step-by-step Spice Profiles', 'Foreword on Royal Mughal Banquets'],
    badge: 'Culinary Masterpiece'
  },
  {
    id: 'pub-2',
    title: 'The Village Heritage Kitchen',
    author: 'Culinary Research Guild',
    year: 'Heritage Collection',
    description: 'A visual celebration of traditional clay pot slow-cooking, artisan tandoori breads, and rustic village dining culture.',
    highlights: ['Traditional Cooking Techniques', 'Wood-fired & Clay Oven Secrets', 'Historical Food Lore'],
    badge: 'Cultural Heritage'
  }
];
