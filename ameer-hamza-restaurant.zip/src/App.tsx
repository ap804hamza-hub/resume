import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.tsx';
import { HeroBanner } from './components/HeroBanner.tsx';
import { OnlineOrderSection } from './components/OnlineOrderSection.tsx';
import { BrandConcepts } from './components/BrandConcepts.tsx';
import { AboutSection } from './components/AboutSection.tsx';
import { PublicationsSection } from './components/PublicationsSection.tsx';
import { LocationsSection } from './components/LocationsSection.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { BottomLeftBadge } from './components/BottomLeftBadge.tsx';
import { Footer } from './components/Footer.tsx';
import { CartDrawer } from './components/CartDrawer.tsx';
import { FranchiseModal } from './components/FranchiseModal.tsx';
import { BrandNameModal } from './components/BrandNameModal.tsx';
import { MenuItem, CartItem } from './types.ts';

export default function App() {
  // Brand name set to "Ameer Hamza" as requested
  const [brandName, setBrandName] = useState<string>(() => {
    return localStorage.getItem('snp_brand_name') || "Ameer Hamza";
  });

  // Navigation & section view
  const [activeSection, setActiveSection] = useState<string>('home');

  // Modals & drawers
  const [isBrandModalOpen, setIsBrandModalOpen] = useState(false);
  const [isFranchiseModalOpen, setIsFranchiseModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Cart state
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('snp_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Sync brandName to storage and document title
  useEffect(() => {
    localStorage.setItem('snp_brand_name', brandName);
    document.title = `${brandName} Restaurant | Online Delivery & Buffet - Lahore (0317 0434287)`;
  }, [brandName]);

  // Sync cart to storage
  useEffect(() => {
    localStorage.setItem('snp_cart', JSON.stringify(cart));
  }, [cart]);

  const handleAddToCart = (item: MenuItem, spice?: 'Mild' | 'Medium' | 'Hot', note?: string) => {
    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex((entry) => entry.item.id === item.id);
      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += 1;
        if (spice) updated[existingIndex].selectedSpice = spice;
        if (note) updated[existingIndex].specialNote = note;
        return updated;
      }
      return [...prevCart, { item, quantity: 1, selectedSpice: spice, specialNote: note }];
    });
  };

  const handleUpdateQuantity = (itemId: string, newQty: number) => {
    setCart((prevCart) => {
      if (newQty <= 0) {
        return prevCart.filter((entry) => entry.item.id !== itemId);
      }
      return prevCart.map((entry) =>
        entry.item.id === itemId ? { ...entry, quantity: newQty } : entry
      );
    });
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    if (sectionId === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const cartTotalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartItemIds = new Set(cart.map((c) => c.item.id));

  return (
    <div className="min-h-screen bg-white text-zinc-900 selection:bg-[#e21b22] selection:text-white flex flex-col font-sans">
      {/* Primary Sticky Header */}
      <Header
        brandName={brandName}
        onOpenBrandModal={() => setIsBrandModalOpen(true)}
        onOpenFranchiseModal={() => setIsFranchiseModalOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        cartCount={cartTotalItems}
        activeSection={activeSection}
        onNavigate={scrollToSection}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Exact Hero Section from User Screenshot */}
        <section id="home">
          <HeroBanner
            brandName={brandName}
            onOrderNow={() => scrollToSection('menu')}
            onExploreVillage={() => scrollToSection('brands')}
          />
        </section>

        {/* Online Ordering & Menu Section */}
        <OnlineOrderSection
          brandName={brandName}
          onAddToCart={handleAddToCart}
          cartItemIds={cartItemIds}
        />

        {/* Brand Divisions (Restaurant, Village, Express) */}
        <BrandConcepts
          brandName={brandName}
          onSelectConcept={(_conceptId) => scrollToSection('menu')}
        />

        {/* About Us & Heritage */}
        <AboutSection brandName={brandName} />

        {/* Publications & Cookbooks */}
        <PublicationsSection brandName={brandName} />

        {/* Branches & Locations */}
        <LocationsSection brandName={brandName} />

        {/* Dedicated Contact Us Section with phone 03170434287 */}
        <ContactSection brandName={brandName} />
      </main>

      {/* Footer */}
      <Footer
        brandName={brandName}
        onOpenBrandModal={() => setIsBrandModalOpen(true)}
        onNavigate={scrollToSection}
        onOpenFranchiseModal={() => setIsFranchiseModalOpen(true)}
      />

      {/* Pinned Bottom-Left Ameer Hamza Indicator & Hotline */}
      <BottomLeftBadge name={brandName} phone="03170434287" />

      {/* Slide-over Cart & Lahore Checkout Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onClearCart={handleClearCart}
        brandName={brandName}
      />

      {/* Get a Franchise Modal */}
      <FranchiseModal
        isOpen={isFranchiseModalOpen}
        onClose={() => setIsFranchiseModalOpen(false)}
        brandName={brandName}
      />

      {/* Quick Brand Name Switcher / Customizer */}
      <BrandNameModal
        isOpen={isBrandModalOpen}
        onClose={() => setIsBrandModalOpen(false)}
        currentBrandName={brandName}
        onSaveBrandName={(newName) => setBrandName(newName)}
      />
    </div>
  );
}
