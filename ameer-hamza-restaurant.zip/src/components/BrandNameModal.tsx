import React, { useState } from 'react';
import { X, Sparkles, Check } from 'lucide-react';
import { BrandLogo } from './BrandLogo.tsx';

interface BrandNameModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBrandName: string;
  onSaveBrandName: (newName: string) => void;
}

export const BrandNameModal: React.FC<BrandNameModalProps> = ({
  isOpen,
  onClose,
  currentBrandName,
  onSaveBrandName,
}) => {
  const [inputValue, setInputValue] = useState(currentBrandName);

  if (!isOpen) return null;

  const presets = [
    "Ameer Hamza",
    "Ameer Hamza Restaurant",
    "Hamza's Kitchen",
    "Spice 'n Pepper",
    "Royal 'n Pepper",
    "Zaiqa 'n Pepper",
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onSaveBrandName(inputValue.trim());
      onClose();
    }
  };

  const handleSelectPreset = (name: string) => {
    setInputValue(name);
    onSaveBrandName(name);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-md bg-white border border-zinc-200 rounded-3xl p-6 sm:p-8 shadow-2xl text-zinc-900">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-zinc-400 hover:text-zinc-700 p-1 rounded-lg hover:bg-zinc-100 transition-colors"
          aria-label="Close"
        >
          <X size={20} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="text-[#e21b22]" size={20} />
          <h3 className="text-xl font-bold tracking-tight font-brand text-zinc-950">Customize Brand Name</h3>
        </div>
        <p className="text-xs text-zinc-500 mb-6">
          Change the website name. The logo, hero banners, delivery backpack, and receipts will update immediately.
        </p>

        {/* Live Preview */}
        <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-5 mb-6 flex flex-col items-center justify-center text-center">
          <span className="text-[10px] uppercase tracking-widest text-zinc-400 font-bold mb-3">Live Logo Preview</span>
          <BrandLogo brandName={inputValue || "Ameer Hamza"} size="lg" darkText={true} />
        </div>

        {/* Quick Presets */}
        <div className="mb-5">
          <label className="block text-xs font-bold text-zinc-600 uppercase tracking-wider mb-2">
            Suggested Names
          </label>
          <div className="flex flex-wrap gap-2">
            {presets.map((preset) => {
              const isSelected = inputValue.toLowerCase() === preset.toLowerCase();
              return (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleSelectPreset(preset)}
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? 'border-[#e21b22] bg-[#e21b22] text-white font-semibold'
                      : 'border-zinc-200 bg-zinc-50 text-zinc-700 hover:bg-zinc-100'
                  }`}
                >
                  {isSelected && <Check size={12} className="text-white" />}
                  {preset}
                </button>
              );
            })}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-zinc-700 mb-1.5">
              Custom Name
            </label>
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="e.g. Ameer Hamza"
              className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white transition-colors text-sm"
              autoFocus
            />
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2.5 rounded-xl border border-zinc-300 text-zinc-700 hover:bg-zinc-100 transition-colors text-xs font-bold uppercase tracking-wider"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#e21b22] hover:bg-[#c4121a] text-white font-bold transition-colors text-xs uppercase tracking-wider shadow-md shadow-red-900/20"
            >
              Save Name
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
