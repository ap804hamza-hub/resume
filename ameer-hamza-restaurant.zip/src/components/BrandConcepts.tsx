import React, { useState } from 'react';
import { Utensils, Flame, Zap, MapPin, CheckCircle, ArrowRight } from 'lucide-react';
import { brandConcepts } from '../data/restaurantData.ts';

interface BrandConceptsProps {
  brandName: string;
  onSelectConcept: (conceptId: string) => void;
}

export const BrandConcepts: React.FC<BrandConceptsProps> = ({
  brandName,
  onSelectConcept,
}) => {
  const [activeTab, setActiveTab] = useState<'restaurant' | 'village' | 'express'>('restaurant');

  const selectedConcept = brandConcepts.find((c) => c.id === activeTab) || brandConcepts[0];

  return (
    <section id="brands" className="py-20 bg-zinc-50 text-zinc-900 border-t border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-[#e21b22] text-xs font-bold uppercase tracking-[0.3em] block mb-2">
            Distinct Culinary Divisions
          </span>
          <h2 className="text-3xl sm:text-5xl font-black font-brand uppercase tracking-tight text-zinc-950">
            The {brandName} Group
          </h2>
          <p className="mt-3 text-zinc-600 text-sm sm:text-base leading-relaxed">
            From premier fine dining and traditional Mughal village buffets to lightning-fast express delivery — discover our iconic dining brands.
          </p>
        </div>

        {/* Division Selector Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
          <button
            onClick={() => setActiveTab('restaurant')}
            className={`flex items-center gap-2 px-6 py-3 rounded-full text-sm font-bold uppercase tracking-wider transition-all ${
              activeTab === 'restaurant'
                ? 'bg-[#e21b22] text-white shadow-md shadow-red-900/20'
                : 'bg-white text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 border border-zinc-300 shadow-2xs'
            }`}
          >
            <Utensils size={16} />
            <span>{brandName} Restaurant</span>
          </button>
          <button
            onClick={() => setActiveTab('village')}
            className={`flex items-center gap-2 px-6 py-3 rounded-full text-sm font-bold uppercase tracking-wider transition-all ${
              activeTab === 'village'
                ? 'bg-[#e21b22] text-white shadow-md shadow-red-900/20'
                : 'bg-white text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 border border-zinc-300 shadow-2xs'
            }`}
          >
            <Flame size={16} />
            <span>{brandName} Village</span>
          </button>
          <button
            onClick={() => setActiveTab('express')}
            className={`flex items-center gap-2 px-6 py-3 rounded-full text-sm font-bold uppercase tracking-wider transition-all ${
              activeTab === 'express'
                ? 'bg-[#e21b22] text-white shadow-md shadow-red-900/20'
                : 'bg-white text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 border border-zinc-300 shadow-2xs'
            }`}
          >
            <Zap size={16} />
            <span>{brandName} Express</span>
          </button>
        </div>

        {/* Active Concept Showcase Card */}
        <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
            {/* Visual Media */}
            <div className="lg:col-span-7 relative min-h-[340px] lg:min-h-[460px] overflow-hidden bg-zinc-100">
              <img
                src={selectedConcept.image}
                alt={`${brandName} ${selectedConcept.name}`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent lg:bg-gradient-to-r lg:from-transparent lg:to-black/30" />
              <div className="absolute top-5 left-5 bg-white/95 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-zinc-200 text-xs font-bold text-zinc-900 flex items-center gap-2 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-[#e21b22]" />
                {selectedConcept.tag}
              </div>
            </div>

            {/* Info and Details */}
            <div className="lg:col-span-5 p-6 sm:p-10 flex flex-col justify-between space-y-6">
              <div>
                <span className="text-[#e21b22] text-xs font-bold uppercase tracking-widest">
                  Brand Division
                </span>
                <h3 className="text-2xl sm:text-4xl font-black font-brand text-zinc-950 mt-1">
                  {brandName} {selectedConcept.name}
                </h3>
                <h4 className="text-zinc-600 font-medium text-sm sm:text-base mt-1">
                  {selectedConcept.subtitle}
                </h4>
                <p className="mt-4 text-zinc-600 text-sm leading-relaxed">
                  {selectedConcept.description}
                </p>

                {/* Locations Info */}
                <div className="mt-6 flex items-start gap-2.5 text-xs sm:text-sm text-zinc-700 bg-zinc-50 p-3.5 rounded-xl border border-zinc-200">
                  <MapPin size={16} className="text-[#e21b22] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-zinc-500 font-semibold uppercase text-[10px] block">Primary Locations</span>
                    <span className="text-zinc-900 font-medium">{selectedConcept.location}</span>
                  </div>
                </div>

                {/* Features List */}
                <div className="mt-6 space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 block mb-2">
                    Key Highlights
                  </span>
                  {selectedConcept.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs sm:text-sm text-zinc-700">
                      <CheckCircle size={14} className="text-[#e21b22] shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action */}
              <div className="pt-4 border-t border-zinc-100">
                <button
                  onClick={() => onSelectConcept(selectedConcept.id)}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-[#e21b22] hover:bg-[#c4121a] text-white font-bold text-sm uppercase tracking-wider transition-colors shadow-md shadow-red-900/20"
                >
                  <span>Explore Menu & Order</span>
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
