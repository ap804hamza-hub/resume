import React, { useState } from 'react';
import { ArrowRight, ShoppingBag, Menu, X, Edit3, PhoneCall, MessageCircle } from 'lucide-react';
import { BrandLogo } from './BrandLogo.tsx';

interface HeaderProps {
  brandName: string;
  onOpenBrandModal: () => void;
  onOpenFranchiseModal: () => void;
  onOpenCart: () => void;
  cartCount: number;
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  brandName,
  onOpenBrandModal,
  onOpenFranchiseModal,
  onOpenCart,
  cartCount,
  activeSection,
  onNavigate,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const primaryPhone = "03170434287";
  const formattedPhone = "0317 0434287";

  const handleNavClick = (sectionId: string) => {
    onNavigate(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-zinc-200 text-zinc-900 transition-all shadow-xs">
      {/* Top micro bar for hotline and brand switcher */}
      <div className="hidden lg:flex items-center justify-between px-6 py-1.5 bg-zinc-50 border-b border-zinc-200 text-[11px] text-zinc-600">
        <div className="flex items-center gap-4">
          <a
            href={`tel:${primaryPhone}`}
            className="flex items-center gap-1.5 text-zinc-700 hover:text-[#e21b22] transition-colors"
          >
            <PhoneCall size={12} className="text-[#e21b22]" />
            Lahore Delivery Hotline: <strong className="text-zinc-950 font-mono">{formattedPhone}</strong>
          </a>
          <span className="text-zinc-300">|</span>
          <a
            href={`https://wa.me/92${primaryPhone.slice(1)}`}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1 text-emerald-700 font-semibold hover:underline"
          >
            <MessageCircle size={12} /> WhatsApp: {formattedPhone}
          </a>
          <span className="text-zinc-300">|</span>
          <span className="text-emerald-700 font-medium">Free Home Delivery Across Lahore</span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenBrandModal}
            className="flex items-center gap-1 px-2.5 py-0.5 rounded bg-white hover:bg-zinc-100 text-zinc-700 hover:text-zinc-950 border border-zinc-300 transition-colors shadow-2xs"
            title="Change Website / Brand Name"
          >
            <Edit3 size={11} className="text-[#e21b22]" />
            <span>Brand: <strong className="text-zinc-950">{brandName}</strong> (Edit)</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
        {/* Left: Brand Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => handleNavClick('home')}
            className="text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#e21b22]"
            aria-label="Go to homepage"
          >
            <BrandLogo brandName={brandName} subText="Restaurant" size="md" darkText={true} />
          </button>
        </div>

        {/* Center: Nav links (Desktop) */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-zinc-700">
          <button
            onClick={() => handleNavClick('home')}
            className={`transition-colors hover:text-[#e21b22] whitespace-nowrap relative py-1 ${
              activeSection === 'home' ? 'text-zinc-950 font-bold' : ''
            }`}
          >
            Home
            {activeSection === 'home' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#e21b22]" />
            )}
          </button>
          <button
            onClick={() => handleNavClick('menu')}
            className={`transition-colors hover:text-[#e21b22] whitespace-nowrap relative py-1 ${
              activeSection === 'menu' ? 'text-zinc-950 font-bold' : ''
            }`}
          >
            Order Online
            {activeSection === 'menu' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#e21b22]" />
            )}
          </button>
          <button
            onClick={() => handleNavClick('brands')}
            className={`transition-colors hover:text-[#e21b22] whitespace-nowrap relative py-1 ${
              activeSection === 'brands' ? 'text-zinc-950 font-bold' : ''
            }`}
          >
            Our Brands
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className={`transition-colors hover:text-[#e21b22] whitespace-nowrap relative py-1 ${
              activeSection === 'about' ? 'text-zinc-950 font-bold' : ''
            }`}
          >
            About Us
          </button>
          <button
            onClick={() => handleNavClick('locations')}
            className={`transition-colors hover:text-[#e21b22] whitespace-nowrap relative py-1 ${
              activeSection === 'locations' ? 'text-zinc-950 font-bold' : ''
            }`}
          >
            Branches
          </button>
          <button
            onClick={() => handleNavClick('contact')}
            className={`transition-colors hover:text-[#e21b22] whitespace-nowrap relative py-1 ${
              activeSection === 'contact' ? 'text-[#e21b22] font-extrabold' : 'text-zinc-800'
            }`}
          >
            Contact ({formattedPhone})
            {activeSection === 'contact' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#e21b22]" />
            )}
          </button>
        </nav>

        {/* Right: Actions */}
        <div className="flex items-center gap-3">
          {/* Quick Edit Name Button (Mobile visible) */}
          <button
            onClick={onOpenBrandModal}
            className="md:hidden p-2 text-zinc-600 hover:text-zinc-950 rounded-lg hover:bg-zinc-100 transition-colors"
            title="Edit Brand Name"
          >
            <Edit3 size={18} />
          </button>

          {/* Get a Franchise Button */}
          <button
            onClick={onOpenFranchiseModal}
            className="hidden sm:inline-flex items-center justify-center border border-zinc-400 text-zinc-800 hover:bg-zinc-900 hover:text-white font-semibold text-xs sm:text-sm px-4 sm:px-5 py-2 rounded-full transition-all duration-200 whitespace-nowrap"
          >
            Get a Franchise
          </button>

          {/* Order Online Button */}
          <button
            onClick={() => handleNavClick('menu')}
            className="inline-flex items-center gap-2 bg-[#e21b22] hover:bg-[#c4121a] text-white font-bold text-xs sm:text-sm px-4 sm:px-5 py-2 rounded-full transition-all duration-200 shadow-md shadow-red-900/20 whitespace-nowrap group"
          >
            <span>Order Online</span>
            <span className="w-5 h-5 rounded-full bg-white flex items-center justify-center text-[#e21b22] group-hover:translate-x-0.5 transition-transform">
              <ArrowRight size={12} strokeWidth={3} />
            </span>
          </button>

          {/* Cart Drawer Trigger */}
          <button
            onClick={onOpenCart}
            className="relative p-2.5 text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 rounded-full transition-colors ml-1"
            aria-label="View shopping bag"
          >
            <ShoppingBag size={20} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#e21b22] text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-sm">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-zinc-700 hover:text-zinc-950 focus:outline-none"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-zinc-200 px-6 py-5 space-y-4 animate-fade-in shadow-lg">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-100">
            <span className="text-xs text-zinc-500">Brand: <strong className="text-zinc-900">{brandName}</strong></span>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBrandModal();
              }}
              className="text-xs text-[#e21b22] font-semibold flex items-center gap-1"
            >
              <Edit3 size={12} /> Change
            </button>
          </div>

          <div className="flex flex-col space-y-3 text-sm font-medium text-zinc-700">
            <button
              onClick={() => handleNavClick('home')}
              className="text-left py-1 hover:text-zinc-950"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('menu')}
              className="text-left py-1 text-[#e21b22] font-bold"
            >
              Order Online / Menu
            </button>
            <button
              onClick={() => handleNavClick('brands')}
              className="text-left py-1 hover:text-zinc-950"
            >
              Our Brands (Village, Express, Restaurant)
            </button>
            <button
              onClick={() => handleNavClick('about')}
              className="text-left py-1 hover:text-zinc-950"
            >
              About Us
            </button>
            <button
              onClick={() => handleNavClick('locations')}
              className="text-left py-1 hover:text-zinc-950"
            >
              Branches
            </button>
            <button
              onClick={() => handleNavClick('contact')}
              className="text-left py-1 text-[#e21b22] font-bold"
            >
              Contact Us ({formattedPhone})
            </button>
          </div>

          <div className="pt-2 flex flex-col gap-2">
            <a
              href={`tel:${primaryPhone}`}
              className="w-full py-2.5 rounded-full bg-[#e21b22] text-white font-bold text-xs text-center flex items-center justify-center gap-2"
            >
              <PhoneCall size={14} /> Call {formattedPhone}
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenFranchiseModal();
              }}
              className="w-full py-2.5 rounded-full border border-zinc-300 text-zinc-800 font-semibold text-xs text-center"
            >
              Get a Franchise
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
