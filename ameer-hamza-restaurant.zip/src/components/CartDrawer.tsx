import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, CheckCircle2, Clock, Phone, MapPin } from 'lucide-react';
import { CartItem } from '../types.ts';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (itemId: string, newQty: number) => void;
  onClearCart: () => void;
  brandName: string;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onClearCart,
  brandName,
}) => {
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryArea, setDeliveryArea] = useState('Gulberg III');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'card' | 'jazzcash'>('cod');
  const [orderId, setOrderId] = useState('');

  const primaryPhone = "03170434287";
  const formattedPhone = "0317 0434287";

  if (!isOpen) return null;

  const lahoreAreas = [
    'Gulberg (I, II, III)',
    'DHA Phase 1 - 4',
    'DHA Phase 5 & 6',
    'Bahria Town Lahore',
    'Model Town',
    'Johar Town',
    'Cantt & Saddar',
    'Mall Road & Civil Lines',
    'Faisal Town & Garden Town',
    'Wapda Town & Valencia',
  ];

  const subtotal = items.reduce((sum, entry) => sum + entry.item.price * entry.quantity, 0);
  const deliveryFee = 0; // Free delivery all over Lahore as advertised!
  const grandTotal = subtotal + deliveryFee;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !deliveryAddress) {
      alert('Please fill in your name, phone number, and delivery address.');
      return;
    }
    const generatedId = `AH-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderId(generatedId);
    setCheckoutStep('success');
  };

  const handleResetAndClose = () => {
    onClearCart();
    setCheckoutStep('cart');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="w-full max-w-lg bg-white border-l border-zinc-200 h-full flex flex-col text-zinc-900 shadow-2xl relative">
        {/* Header */}
        <div className="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
          <div className="flex items-center gap-2">
            <ShoppingBag className="text-[#e21b22]" size={20} />
            <h3 className="text-lg font-bold font-brand text-zinc-950">
              {checkoutStep === 'cart' && 'Your Delivery Bag'}
              {checkoutStep === 'checkout' && 'Lahore Delivery Details'}
              {checkoutStep === 'success' && 'Order Confirmed!'}
            </h3>
          </div>
          <button
            onClick={checkoutStep === 'success' ? handleResetAndClose : onClose}
            className="p-1.5 text-zinc-400 hover:text-zinc-700 rounded-lg hover:bg-zinc-200 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* BODY */}
        <div className="flex-1 overflow-y-auto p-5">
          {checkoutStep === 'cart' && (
            <>
              {items.length === 0 ? (
                <div className="py-24 text-center">
                  <div className="w-16 h-16 rounded-full bg-zinc-100 border border-zinc-200 flex items-center justify-center mx-auto mb-4 text-zinc-400">
                    <ShoppingBag size={28} />
                  </div>
                  <h4 className="text-base font-bold text-zinc-800">Your bag is empty</h4>
                  <p className="text-xs text-zinc-500 mt-1 max-w-xs mx-auto">
                    Explore our Lahori Karahi, Village BBQ, and Express Burgers to start your order.
                  </p>
                  <button
                    onClick={onClose}
                    className="mt-6 px-6 py-2.5 rounded-full bg-[#e21b22] hover:bg-[#c4121a] text-white text-xs font-bold uppercase tracking-wider transition-colors shadow-sm"
                  >
                    Browse Menu
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Delivery banner */}
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2 text-xs text-emerald-800">
                    <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                    <span>
                      🎉 <strong>Free Delivery in Lahore</strong> applied to your order!
                    </span>
                  </div>

                  {/* Items List */}
                  <div className="divide-y divide-zinc-100">
                    {items.map(({ item, quantity, selectedSpice, specialNote }) => (
                      <div key={item.id} className="py-4 flex gap-3 items-start">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 rounded-xl object-cover border border-zinc-200 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-bold text-zinc-950 truncate">{item.name}</h4>
                          <div className="text-xs text-zinc-500 mt-0.5 font-mono">
                            Rs. {item.price.toLocaleString()} each
                          </div>
                          {selectedSpice && (
                            <span className="inline-block text-[10px] text-zinc-600 bg-zinc-100 px-2 py-0.5 rounded mt-1 font-medium">
                              Spice: {selectedSpice}
                            </span>
                          )}
                          {specialNote && (
                            <p className="text-[10px] text-zinc-500 italic mt-0.5 truncate">
                              Note: {specialNote}
                            </p>
                          )}

                          {/* Stepper controls */}
                          <div className="flex items-center gap-2 mt-2">
                            <button
                              onClick={() => onUpdateQuantity(item.id, quantity - 1)}
                              className="w-7 h-7 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-700 flex items-center justify-center border border-zinc-200"
                              title="Decrease"
                            >
                              {quantity === 1 ? <Trash2 size={12} className="text-red-500" /> : <Minus size={12} />}
                            </button>
                            <span className="text-xs font-bold font-mono px-2 text-zinc-900">{quantity}</span>
                            <button
                              onClick={() => onUpdateQuantity(item.id, quantity + 1)}
                              className="w-7 h-7 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-700 flex items-center justify-center border border-zinc-200"
                              title="Increase"
                            >
                              <Plus size={12} />
                            </button>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-sm font-bold font-mono tabular-nums text-zinc-950">
                            Rs. {(item.price * quantity).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {checkoutStep === 'checkout' && (
            <form onSubmit={handlePlaceOrder} id="checkout-form" className="space-y-4">
              <div className="bg-red-50 p-3.5 rounded-xl border border-red-100 text-xs text-zinc-700">
                <span className="font-bold text-zinc-900 block mb-1">Fast Delivery to Lahore:</span>
                Average arrival time: <strong className="text-[#e21b22]">30–45 mins</strong> via {brandName} fleet.
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1.5 uppercase">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Ameer Hamza"
                  className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1.5 uppercase">
                  Phone Number (For Rider Verification) *
                </label>
                <input
                  type="tel"
                  required
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="0317 0434287"
                  className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1.5 uppercase">
                  Lahore Delivery Area *
                </label>
                <select
                  value={deliveryArea}
                  onChange={(e) => setDeliveryArea(e.target.value)}
                  className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 focus:outline-none focus:border-[#e21b22] focus:bg-white"
                >
                  {lahoreAreas.map((area) => (
                    <option key={area} value={area} className="bg-white text-zinc-900">
                      {area}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-1.5 uppercase">
                  Complete Delivery Address (House / Street / Landmark) *
                </label>
                <textarea
                  required
                  rows={2}
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  placeholder="e.g. House 42-B, Street 7, Block G, Gulberg III"
                  className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 mb-2 uppercase">
                  Payment Method
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cod')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                      paymentMethod === 'cod'
                        ? 'border-[#e21b22] bg-[#e21b22] text-white'
                        : 'border-zinc-200 bg-zinc-50 text-zinc-700'
                    }`}
                  >
                    Cash on Delivery
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                      paymentMethod === 'card'
                        ? 'border-[#e21b22] bg-[#e21b22] text-white'
                        : 'border-zinc-200 bg-zinc-50 text-zinc-700'
                    }`}
                  >
                    Card on Delivery
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('jazzcash')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                      paymentMethod === 'jazzcash'
                        ? 'border-[#e21b22] bg-[#e21b22] text-white'
                        : 'border-zinc-200 bg-zinc-50 text-zinc-700'
                    }`}
                  >
                    JazzCash / EasyPaisa
                  </button>
                </div>
              </div>
            </form>
          )}

          {checkoutStep === 'success' && (
            <div className="py-8 text-center space-y-5">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 size={36} />
              </div>

              <div>
                <span className="text-xs uppercase font-bold text-emerald-700 tracking-wider">
                  Order Successfully Dispatched
                </span>
                <h3 className="text-2xl font-bold font-brand text-zinc-950 mt-1">
                  Thank You, {customerName}!
                </h3>
                <p className="text-xs text-zinc-600 mt-1">
                  Your meal is being prepared hot and fresh in our nearest {brandName} kitchen.
                </p>
              </div>

              {/* Order Receipt Box */}
              <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 text-left space-y-3">
                <div className="flex items-center justify-between text-xs pb-2 border-b border-zinc-200">
                  <span className="text-zinc-500 font-bold uppercase">Order Reference:</span>
                  <span className="font-mono font-bold text-[#e21b22]">{orderId}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-600">Estimated Delivery:</span>
                  <span className="font-bold text-zinc-900 flex items-center gap-1">
                    <Clock size={12} className="text-emerald-600" /> 35 Mins
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-600">Destination:</span>
                  <span className="text-zinc-900 font-medium text-right truncate max-w-[200px]">
                    {deliveryArea}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-600">Payment:</span>
                  <span className="text-zinc-900 font-semibold uppercase">{paymentMethod}</span>
                </div>
                <div className="flex items-center justify-between text-sm pt-2 border-t border-zinc-200 font-bold">
                  <span>Grand Total:</span>
                  <span className="font-mono text-[#e21b22]">Rs. {grandTotal.toLocaleString()}</span>
                </div>
              </div>

              {/* Delivery Helpline */}
              <div className="bg-white p-3 rounded-xl border border-zinc-200 text-xs text-zinc-600 flex items-center justify-between shadow-2xs">
                <span>Rider hotline:</span>
                <a href={`tel:${primaryPhone}`} className="text-[#e21b22] font-bold font-mono">
                  {formattedPhone}
                </a>
              </div>
            </div>
          )}
        </div>

        {/* FOOTER ACTIONS */}
        {items.length > 0 && checkoutStep !== 'success' && (
          <div className="p-5 border-t border-zinc-200 bg-zinc-50 space-y-3">
            <div className="space-y-1.5 text-xs text-zinc-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono text-zinc-900 font-bold">Rs. {subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-emerald-700">
                <span>Lahore Delivery Fee</span>
                <span className="font-bold uppercase">FREE</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-zinc-950 pt-2 border-t border-zinc-200">
                <span>Total Amount</span>
                <span className="font-mono text-base text-[#e21b22]">
                  Rs. {grandTotal.toLocaleString()}
                </span>
              </div>
            </div>

            {checkoutStep === 'cart' ? (
              <button
                onClick={() => setCheckoutStep('checkout')}
                className="w-full py-3 rounded-xl bg-[#e21b22] hover:bg-[#c4121a] text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md shadow-red-900/20 transition-colors"
              >
                <span>Proceed to Lahore Checkout</span>
                <ArrowRight size={16} />
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setCheckoutStep('cart')}
                  className="px-4 py-3 rounded-xl border border-zinc-300 text-zinc-700 hover:bg-zinc-200 text-xs font-bold uppercase tracking-wider"
                >
                  Back
                </button>
                <button
                  type="submit"
                  form="checkout-form"
                  className="flex-1 py-3 rounded-xl bg-[#e21b22] hover:bg-[#c4121a] text-white font-bold text-xs uppercase tracking-wider shadow-md shadow-red-900/20 transition-colors"
                >
                  Confirm & Place Order
                </button>
              </div>
            )}
          </div>
        )}

        {checkoutStep === 'success' && (
          <div className="p-5 border-t border-zinc-200 bg-zinc-50">
            <button
              onClick={handleResetAndClose}
              className="w-full py-3 rounded-xl bg-[#e21b22] hover:bg-[#c4121a] text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-sm"
            >
              Done & Start New Order
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
