import React, { useState } from 'react';
import { Search, Plus, Check, Flame, Users, Sparkles, Phone, MessageCircle } from 'lucide-react';
import { MenuItem } from '../types.ts';
import { menuItems } from '../data/restaurantData.ts';

interface OnlineOrderSectionProps {
  brandName: string;
  onAddToCart: (item: MenuItem, spice?: 'Mild' | 'Medium' | 'Hot', note?: string) => void;
  cartItemIds: Set<string>;
}

export const OnlineOrderSection: React.FC<OnlineOrderSectionProps> = ({
  brandName,
  onAddToCart,
  cartItemIds,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);
  const [selectedSpice, setSelectedSpice] = useState<'Mild' | 'Medium' | 'Hot'>('Medium');
  const [itemNote, setItemNote] = useState<string>('');
  const [recentlyAddedId, setRecentlyAddedId] = useState<string | null>(null);

  const primaryPhone = "03170434287";
  const formattedPhone = "0317 0434287";

  const categories = [
    { id: 'all', label: 'All Items' },
    { id: 'deals', label: 'Deals & Platters' },
    { id: 'karahi', label: 'Karahi & Handi' },
    { id: 'bbq', label: 'Charcoal BBQ' },
    { id: 'fastfood', label: 'Burgers & Fried Chicken' },
    { id: 'pizza', label: 'Pizzas' },
    { id: 'dessert', label: 'Desserts & Coolers' },
  ];

  const filteredItems = menuItems.filter((item) => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleOpenCustomize = (item: MenuItem) => {
    setCustomizingItem(item);
    setSelectedSpice(item.spiceLevel || 'Medium');
    setItemNote('');
  };

  const handleConfirmAddToCart = () => {
    if (!customizingItem) return;
    onAddToCart(customizingItem, selectedSpice, itemNote);
    setRecentlyAddedId(customizingItem.id);
    setTimeout(() => setRecentlyAddedId(null), 1800);
    setCustomizingItem(null);
  };

  const handleQuickAdd = (item: MenuItem, e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(item, item.spiceLevel || 'Medium');
    setRecentlyAddedId(item.id);
    setTimeout(() => setRecentlyAddedId(null), 1800);
  };

  return (
    <section id="menu" className="py-20 bg-white text-zinc-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-zinc-200">
          <div>
            <span className="text-[#e21b22] text-xs font-bold uppercase tracking-[0.3em] block mb-2">
              Free Delivery Across Lahore
            </span>
            <h2 className="text-3xl sm:text-5xl font-black font-brand uppercase tracking-tight text-zinc-950">
              Order Online from {brandName}
            </h2>
            <p className="mt-2 text-zinc-600 text-sm max-w-xl">
              Freshly cooked to order and delivered piping hot. Guaranteed delivery in 30–45 minutes anywhere in Lahore! Call directly at <strong className="text-zinc-900">{formattedPhone}</strong>.
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search karahi, burgers, deals..."
              className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-full text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white transition-colors"
            />
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar scroll-smooth">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-5 py-2 rounded-full text-xs sm:text-sm font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-[#e21b22] text-white shadow-md shadow-red-900/20'
                  : 'bg-zinc-100 text-zinc-700 hover:text-zinc-950 hover:bg-zinc-200 border border-zinc-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Menu Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="py-20 text-center bg-zinc-50 rounded-2xl border border-zinc-200">
            <p className="text-zinc-500 text-base">No menu items found matching "{searchQuery}"</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="mt-4 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-xs font-semibold text-white transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => {
              const inCart = cartItemIds.has(item.id);
              const wasJustAdded = recentlyAddedId === item.id;

              return (
                <div
                  key={item.id}
                  onClick={() => handleOpenCustomize(item)}
                  className="bg-white border border-zinc-200 rounded-2xl overflow-hidden hover:border-zinc-300 transition-all duration-300 flex flex-col justify-between group cursor-pointer shadow-xs hover:shadow-xl"
                >
                  {/* Top media container */}
                  <div className="relative aspect-[16/10] overflow-hidden bg-zinc-100">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60" />

                    {/* Badge */}
                    {item.badge && (
                      <div className="absolute top-3 left-3 bg-[#e21b22] text-white text-[11px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md shadow-sm">
                        {item.badge}
                      </div>
                    )}

                    {/* Serves info */}
                    {item.serves && (
                      <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm text-zinc-800 text-[10px] font-bold px-2.5 py-1 rounded-md border border-zinc-200 shadow-2xs flex items-center gap-1">
                        <Users size={12} className="text-zinc-600" />
                        <span>{item.serves}</span>
                      </div>
                    )}

                    {/* Spice indicator */}
                    {item.isSpicy && (
                      <div className="absolute bottom-3 left-3 flex items-center gap-1 bg-red-100 border border-red-200 text-red-700 text-[10px] font-bold px-2 py-0.5 rounded shadow-2xs">
                        <Flame size={12} className="text-red-600" />
                        <span>{item.spiceLevel || 'Spicy'}</span>
                      </div>
                    )}
                  </div>

                  {/* Body Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-zinc-950 group-hover:text-[#e21b22] transition-colors leading-snug font-brand">
                        {item.name}
                      </h3>
                      <p className="mt-2 text-xs text-zinc-600 leading-relaxed line-clamp-2">
                        {item.description}
                      </p>
                    </div>

                    {/* Price and Add button */}
                    <div className="pt-3 border-t border-zinc-100 flex items-center justify-between">
                      <div className="flex flex-col">
                        <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">
                          Price
                        </span>
                        <span className="text-lg font-black font-mono tabular-nums text-zinc-950">
                          Rs. {item.price.toLocaleString()}
                        </span>
                      </div>

                      <button
                        onClick={(e) => handleQuickAdd(item, e)}
                        className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all shadow-xs ${
                          wasJustAdded
                            ? 'bg-emerald-600 text-white'
                            : inCart
                            ? 'bg-zinc-800 text-white hover:bg-[#e21b22]'
                            : 'bg-[#e21b22] text-white hover:bg-[#c4121a]'
                        }`}
                        title="Add item to order"
                      >
                        {wasJustAdded ? (
                          <>
                            <Check size={14} /> Added
                          </>
                        ) : inCart ? (
                          <>
                            <Plus size={14} /> Add More
                          </>
                        ) : (
                          <>
                            <Plus size={14} /> Add to Cart
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Bottom Hotline Strip featuring 03170434287 */}
        <div className="mt-16 bg-gradient-to-r from-red-50 via-zinc-50 to-white border-2 border-red-100 rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xs">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-[#e21b22] text-white flex items-center justify-center shadow-md shadow-red-900/30 shrink-0">
              <Phone size={24} />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-widest text-[#e21b22]">
                Instant Lahore Phone Ordering
              </span>
              <h4 className="text-xl sm:text-2xl font-black font-mono text-zinc-950 mt-0.5">
                {formattedPhone}
              </h4>
              <p className="text-xs text-zinc-600 mt-1">
                Order directly with our call center or WhatsApp. Dedicated to {brandName} customers.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <a
              href={`tel:${primaryPhone}`}
              className="px-6 py-3 rounded-full bg-[#e21b22] hover:bg-[#c4121a] text-white text-xs font-black uppercase tracking-wider transition-colors shadow-sm flex items-center gap-1.5"
            >
              <Phone size={14} /> Call {formattedPhone}
            </a>
            <a
              href={`https://wa.me/92${primaryPhone.slice(1)}`}
              target="_blank"
              rel="noreferrer"
              className="px-6 py-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-wider transition-colors shadow-sm flex items-center gap-1.5"
            >
              <MessageCircle size={14} /> WhatsApp Us
            </a>
          </div>
        </div>
      </div>

      {/* Item Customization Modal */}
      {customizingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fade-in">
          <div className="relative w-full max-w-lg bg-white border border-zinc-200 rounded-3xl p-6 sm:p-8 shadow-2xl text-zinc-900">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-zinc-100">
              <div>
                <h3 className="text-xl font-bold font-brand text-zinc-950">{customizingItem.name}</h3>
                <p className="text-xs text-zinc-500 mt-1">{customizingItem.description}</p>
                <div className="text-base font-mono font-bold text-[#e21b22] mt-2">
                  Rs. {customizingItem.price.toLocaleString()}
                </div>
              </div>
            </div>

            {/* Spice Level selection */}
            {customizingItem.isSpicy && (
              <div className="mt-5">
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-600 mb-2">
                  Select Spice Level
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Mild', 'Medium', 'Hot'] as const).map((level) => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => setSelectedSpice(level)}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                        selectedSpice === level
                          ? 'border-[#e21b22] bg-[#e21b22] text-white'
                          : 'border-zinc-200 bg-zinc-50 text-zinc-700 hover:bg-zinc-100'
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Special Instructions */}
            <div className="mt-5">
              <label className="block text-xs font-bold uppercase tracking-wider text-zinc-600 mb-2">
                Special Cooking Instructions (Optional)
              </label>
              <textarea
                value={itemNote}
                onChange={(e) => setItemNote(e.target.value)}
                placeholder="e.g. Less oil, extra ginger, separate raita..."
                rows={2}
                className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white"
              />
            </div>

            {/* Actions */}
            <div className="mt-6 flex items-center gap-3 pt-3 border-t border-zinc-100">
              <button
                type="button"
                onClick={() => setCustomizingItem(null)}
                className="flex-1 px-4 py-2.5 rounded-xl border border-zinc-300 text-zinc-700 hover:bg-zinc-100 text-xs font-bold uppercase tracking-wider"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmAddToCart}
                className="flex-1 px-4 py-2.5 rounded-xl bg-[#e21b22] hover:bg-[#c4121a] text-white text-xs font-bold uppercase tracking-wider shadow-md shadow-red-900/30"
              >
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
