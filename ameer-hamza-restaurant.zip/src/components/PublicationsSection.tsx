import React, { useState } from 'react';
import { BookOpen, Check, Award, ArrowUpRight } from 'lucide-react';
import { publications } from '../data/restaurantData.ts';

interface PublicationsSectionProps {
  brandName: string;
}

export const PublicationsSection: React.FC<PublicationsSectionProps> = ({ brandName }) => {
  const [inquiredBook, setInquiredBook] = useState<string | null>(null);

  const handleInquire = (title: string) => {
    setInquiredBook(title);
    setTimeout(() => setInquiredBook(null), 3000);
  };

  return (
    <section id="publications" className="py-20 bg-white text-zinc-900 border-t border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[#e21b22] text-xs font-bold uppercase tracking-[0.3em] block mb-2">
            Culinary Literature & Heritage
          </span>
          <h2 className="text-3xl sm:text-5xl font-black font-brand uppercase tracking-tight text-zinc-950">
            {brandName} Publications
          </h2>
          <p className="mt-3 text-zinc-600 text-sm sm:text-base leading-relaxed">
            Acclaimed cookbooks documenting centuries-old culinary traditions, spice secrets, and authentic recipes from our executive master chefs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {publications.map((book) => {
            const hasInquired = inquiredBook === book.title;

            return (
              <div
                key={book.id}
                className="bg-zinc-50 border border-zinc-200 rounded-3xl p-6 sm:p-8 flex flex-col justify-between hover:border-zinc-300 transition-all duration-300 shadow-xs hover:shadow-md"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <span className="text-xs uppercase font-bold text-[#e21b22] tracking-wider flex items-center gap-1.5">
                      <Award size={14} />
                      {book.badge}
                    </span>
                    <span className="text-[11px] text-zinc-500 font-mono">{book.year}</span>
                  </div>

                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-red-50 border border-red-100 flex items-center justify-center text-[#e21b22] shrink-0">
                      <BookOpen size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl sm:text-2xl font-bold font-brand text-zinc-950 leading-snug">
                        {book.title}
                      </h3>
                      <p className="text-xs text-zinc-500 mt-0.5">By {book.author}</p>
                    </div>
                  </div>

                  <p className="text-zinc-600 text-xs sm:text-sm leading-relaxed mb-6">
                    {book.description}
                  </p>

                  <div className="space-y-2 mb-6 pt-4 border-t border-zinc-200">
                    <span className="text-[11px] font-bold text-zinc-600 uppercase tracking-wider block">
                      Inside This Edition:
                    </span>
                    {book.highlights.map((h, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-zinc-700">
                        <Check size={14} className="text-[#e21b22] shrink-0" />
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-zinc-200 flex items-center justify-between">
                  <span className="text-xs text-zinc-500">Available at all Lahore branches</span>
                  <button
                    onClick={() => handleInquire(book.title)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white hover:bg-[#e21b22] hover:text-white text-zinc-800 text-xs font-bold uppercase tracking-wider transition-colors border border-zinc-300 shadow-2xs"
                  >
                    {hasInquired ? (
                      <>
                        <Check size={14} className="text-emerald-600" /> Inquired
                      </>
                    ) : (
                      <>
                        Inquire Copy <ArrowUpRight size={14} />
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
