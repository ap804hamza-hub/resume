import React, { useState } from 'react';
import { MapPin, Phone, Clock, Navigation, CheckCircle } from 'lucide-react';
import { lahoreBranches } from '../data/restaurantData.ts';

interface LocationsSectionProps {
  brandName: string;
}

export const LocationsSection: React.FC<LocationsSectionProps> = ({ brandName }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const primaryPhone = "03170434287";
  const formattedPhone = "0317 0434287";

  const handleCopyPhone = (id: string, phone: string) => {
    navigator.clipboard?.writeText(phone);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <section id="locations" className="py-20 bg-zinc-50 text-zinc-900 border-t border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <span className="text-[#e21b22] text-xs font-bold uppercase tracking-[0.3em] block mb-2">
              Lahore & Nationwide Outlets
            </span>
            <h2 className="text-3xl sm:text-5xl font-black font-brand uppercase tracking-tight text-zinc-950">
              Our Branches in Lahore
            </h2>
            <p className="mt-2 text-zinc-600 text-sm max-w-xl">
              Visit our dine-in restaurants or order express delivery straight from our local kitchen hubs.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white p-3.5 rounded-2xl border border-zinc-200 shadow-xs">
            <span className="text-xs text-zinc-500 font-semibold uppercase">Universal UAN:</span>
            <a
              href={`tel:${primaryPhone}`}
              className="text-[#e21b22] font-black font-mono text-base hover:underline"
            >
              {formattedPhone}
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {lahoreBranches.map((branch) => (
            <div
              key={branch.id}
              className="bg-white border border-zinc-200 rounded-2xl p-6 flex flex-col justify-between hover:border-zinc-300 transition-all duration-300 shadow-xs hover:shadow-md"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <h3 className="text-lg font-bold text-zinc-950 font-brand">{branch.name}</h3>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#e21b22] bg-red-50 border border-red-200 px-2 py-0.5 rounded">
                    {branch.type.includes('Buffet') ? 'Village Buffet' : 'Restaurant & Delivery'}
                  </span>
                </div>

                <div className="space-y-3 text-xs text-zinc-600 mt-4">
                  <div className="flex items-start gap-2.5">
                    <MapPin size={15} className="text-[#e21b22] shrink-0 mt-0.5" />
                    <span className="text-zinc-800 leading-relaxed">{branch.address}</span>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <Clock size={15} className="text-zinc-400 shrink-0" />
                    <span>{branch.timing}</span>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <Phone size={15} className="text-zinc-400 shrink-0" />
                    <span className="font-mono text-zinc-800 font-semibold">{formattedPhone}</span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-zinc-100 flex items-center justify-between">
                <button
                  onClick={() => handleCopyPhone(branch.id, formattedPhone)}
                  className="text-xs text-zinc-500 hover:text-zinc-900 flex items-center gap-1 transition-colors"
                >
                  {copiedId === branch.id ? (
                    <>
                      <CheckCircle size={13} className="text-emerald-600" /> Copied Hotline
                    </>
                  ) : (
                    <>Copy Hotline</>
                  )}
                </button>

                <a
                  href={`https://maps.google.com/?q=${encodeURIComponent(`${branch.name} ${brandName} Lahore`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-100 hover:bg-[#e21b22] hover:text-white text-zinc-800 text-xs font-semibold transition-colors"
                >
                  <Navigation size={12} /> Directions
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
