import React, { useState } from 'react';
import { Phone, Mail, MapPin, Send, MessageCircle, Clock, CheckCircle2, ShieldCheck, Heart } from 'lucide-react';

interface ContactSectionProps {
  brandName: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ brandName }) => {
  const primaryPhone = "03170434287";
  const formattedPhone = "0317 0434287";

  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    subject: 'Order & Delivery Inquiry',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    setFormData({
      name: '',
      phone: '',
      email: '',
      subject: 'Order & Delivery Inquiry',
      message: '',
    });
  };

  return (
    <section id="contact" className="py-20 bg-white text-zinc-900 border-t border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-[#e21b22] text-xs font-bold uppercase tracking-[0.3em] block mb-2">
            Get In Touch
          </span>
          <h2 className="text-3xl sm:text-5xl font-black font-brand uppercase tracking-tight text-zinc-900">
            Contact {brandName}
          </h2>
          <p className="mt-3 text-zinc-600 text-sm sm:text-base leading-relaxed">
            Have a question, feedback, or need instant home delivery in Lahore? Call or WhatsApp our hotline directly at <strong className="text-zinc-900">{formattedPhone}</strong>.
          </p>
        </div>

        {/* 3 Core Contact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Main Phone Card with 03170434287 */}
          <div className="bg-zinc-50 border-2 border-red-100 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-sm hover:shadow-md transition-shadow">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-[#e21b22]/10 border border-[#e21b22]/20 flex items-center justify-center text-[#e21b22] mb-5">
                <Phone size={24} />
              </div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500 block mb-1">
                Direct Hotline & Delivery
              </span>
              <h3 className="text-2xl font-black font-mono text-zinc-950 mb-2">
                {formattedPhone}
              </h3>
              <p className="text-xs text-zinc-600 leading-relaxed">
                Dedicated contact line for {brandName}. Instant Lahore order taking, table reservations, and general inquiries.
              </p>
            </div>

            <div className="pt-6 flex flex-col sm:flex-row gap-2">
              <a
                href={`tel:${primaryPhone}`}
                className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#e21b22] hover:bg-[#c4121a] text-white text-xs font-bold uppercase tracking-wider transition-colors shadow-sm"
              >
                <Phone size={14} /> Call Now
              </a>
              <a
                href={`https://wa.me/92${primaryPhone.slice(1)}?text=Hello%20${encodeURIComponent(brandName)}%2C%20I%20would%20like%20to%20place%20an%20order`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold uppercase tracking-wider transition-colors shadow-sm"
              >
                <MessageCircle size={14} /> WhatsApp
              </a>
            </div>
          </div>

          {/* Lahore Delivery Hours */}
          <div className="bg-zinc-50 border border-zinc-200 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-sm">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-zinc-200/80 flex items-center justify-center text-zinc-800 mb-5">
                <Clock size={24} />
              </div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500 block mb-1">
                Operating Schedule
              </span>
              <h3 className="text-xl font-bold font-brand text-zinc-900 mb-2">
                12:00 PM – 2:00 AM Daily
              </h3>
              <p className="text-xs text-zinc-600 leading-relaxed">
                Kitchens active 7 days a week. Express hot delivery across all sectors of Lahore with late-night service.
              </p>
            </div>

            <div className="pt-6 border-t border-zinc-200">
              <span className="text-xs font-bold text-emerald-700 flex items-center gap-1.5">
                <ShieldCheck size={16} /> Free Delivery on All Orders in Lahore
              </span>
            </div>
          </div>

          {/* Central Headquarters & Branches */}
          <div className="bg-zinc-50 border border-zinc-200 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-sm">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-zinc-200/80 flex items-center justify-center text-zinc-800 mb-5">
                <MapPin size={24} />
              </div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500 block mb-1">
                Central Lahore Kitchen
              </span>
              <h3 className="text-xl font-bold font-brand text-zinc-900 mb-2">
                Gulberg & Mall Road Hubs
              </h3>
              <p className="text-xs text-zinc-600 leading-relaxed">
                48 The Mall & Liberty Market Gulberg III, Lahore, Punjab, Pakistan. Serving all surrounding sectors.
              </p>
            </div>

            <div className="pt-6 border-t border-zinc-200">
              <span className="text-xs text-zinc-500">
                UAN: <strong className="text-zinc-800">{formattedPhone}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Contact Form & Direct Inquiries Container */}
        <div className="bg-zinc-50 border border-zinc-200 rounded-3xl p-6 sm:p-12 shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Left Info Column */}
            <div className="lg:col-span-5 space-y-5">
              <span className="text-xs font-bold uppercase tracking-wider text-[#e21b22]">
                Instant Assistance
              </span>
              <h3 className="text-2xl sm:text-3xl font-black font-brand text-zinc-950">
                Send a Message to {brandName}
              </h3>
              <p className="text-xs sm:text-sm text-zinc-600 leading-relaxed">
                Whether you're arranging a wedding catering banquet, a family dinner, corporate meal boxes, or have feedback about your food delivery, write to us here or call <strong className="text-zinc-900">{formattedPhone}</strong>.
              </p>

              <div className="space-y-3 pt-3">
                <div className="flex items-center gap-3 text-xs text-zinc-700 bg-white p-3.5 rounded-xl border border-zinc-200">
                  <Phone size={16} className="text-[#e21b22] shrink-0" />
                  <span>Call Hotline: <strong className="text-zinc-900 font-mono">{formattedPhone}</strong></span>
                </div>
                <div className="flex items-center gap-3 text-xs text-zinc-700 bg-white p-3.5 rounded-xl border border-zinc-200">
                  <MessageCircle size={16} className="text-emerald-600 shrink-0" />
                  <span>WhatsApp: <strong className="text-zinc-900 font-mono">0317 0434287</strong></span>
                </div>
                <div className="flex items-center gap-3 text-xs text-zinc-700 bg-white p-3.5 rounded-xl border border-zinc-200">
                  <Mail size={16} className="text-[#e21b22] shrink-0" />
                  <span>Official Email: <strong className="text-zinc-900">contact@ameerhamza.pk</strong></span>
                </div>
              </div>
            </div>

            {/* Right Form Column */}
            <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-2xl border border-zinc-200 shadow-sm">
              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1 uppercase">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Mian Ameer Hamza"
                        className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1 uppercase">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="e.g. 0317 0434287"
                        className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1 uppercase">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="hamza@example.com"
                        className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-zinc-700 mb-1 uppercase">
                        Inquiry Topic
                      </label>
                      <select
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 focus:outline-none focus:border-[#e21b22] focus:bg-white"
                      >
                        <option value="Order & Delivery Inquiry">Order & Delivery Inquiry</option>
                        <option value="Table Reservation">Table Reservation</option>
                        <option value="Village Buffet Booking">Village Buffet Booking</option>
                        <option value="Catering & Events">Catering & Events</option>
                        <option value="Customer Feedback">Customer Feedback</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-zinc-700 mb-1 uppercase">
                      Message / Special Order Request *
                    </label>
                    <textarea
                      required
                      rows={3}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Type your message, delivery instructions, or query here..."
                      className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-300 rounded-xl text-xs text-zinc-900 placeholder-zinc-400 focus:outline-none focus:border-[#e21b22] focus:bg-white"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-[11px] text-zinc-500">
                      Or call directly: <strong className="text-zinc-900 font-mono">{formattedPhone}</strong>
                    </span>
                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-xl bg-[#e21b22] hover:bg-[#c4121a] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-md shadow-red-900/20 transition-all"
                    >
                      <Send size={13} /> Send Message
                    </button>
                  </div>
                </form>
              ) : (
                <div className="py-8 text-center space-y-4">
                  <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                    <CheckCircle2 size={32} />
                  </div>
                  <h4 className="text-xl font-bold font-brand text-zinc-900">Message Received!</h4>
                  <p className="text-xs text-zinc-600 max-w-sm mx-auto">
                    Thank you, <strong className="text-zinc-900">{formData.name}</strong>. Our Lahore support team has received your message and will call you back at <strong className="text-zinc-900">{formData.phone}</strong> shortly.
                  </p>
                  <button
                    onClick={handleReset}
                    className="mt-2 px-5 py-2 rounded-xl border border-zinc-300 hover:bg-zinc-100 text-zinc-800 text-xs font-bold"
                  >
                    Send Another Note
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
