import React, { useState } from 'react';
import { Phone, MessageCircle, X, ChevronUp, ChevronDown } from 'lucide-react';

interface BottomLeftBadgeProps {
  name?: string;
  phone?: string;
}

export const BottomLeftBadge: React.FC<BottomLeftBadgeProps> = ({
  name = "Ameer Hamza",
  phone = "03170434287",
}) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const formattedPhone = "0317 0434287";

  return (
    <div className="fixed bottom-4 left-4 z-40 transition-all select-none">
      {isMinimized ? (
        <button
          onClick={() => setIsMinimized(false)}
          className="bg-zinc-950 text-white border border-zinc-700 shadow-2xl rounded-full px-3.5 py-2 flex items-center gap-2 hover:bg-[#e21b22] transition-colors group text-xs font-bold"
          title="Open Ameer Hamza Contact Badge"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{name}</span>
          <ChevronUp size={14} className="text-zinc-400 group-hover:text-white" />
        </button>
      ) : (
        <div className="bg-white text-zinc-900 border border-zinc-200 rounded-2xl shadow-2xl p-3.5 max-w-[270px] backdrop-blur-md transition-all animate-fade-in border-l-4 border-l-[#e21b22]">
          <div className="flex items-center justify-between gap-3 pb-2 border-b border-zinc-100">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-black tracking-tight text-zinc-950 uppercase font-brand">
                {name}
              </span>
            </div>
            <button
              onClick={() => setIsMinimized(true)}
              className="text-zinc-400 hover:text-zinc-600 p-0.5 rounded transition-colors"
              title="Minimize"
            >
              <ChevronDown size={14} />
            </button>
          </div>

          <div className="py-2">
            <span className="text-[10px] text-zinc-500 uppercase tracking-wider block font-semibold">
              Official Hotline:
            </span>
            <a
              href={`tel:${phone}`}
              className="text-sm font-black font-mono text-[#e21b22] hover:underline block"
            >
              {formattedPhone}
            </a>
          </div>

          <div className="flex items-center gap-1.5 pt-1">
            <a
              href={`tel:${phone}`}
              className="flex-1 py-1.5 px-2.5 rounded-lg bg-[#e21b22] hover:bg-[#c4121a] text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-colors"
            >
              <Phone size={11} /> Call
            </a>
            <a
              href={`https://wa.me/92${phone.slice(1)}?text=Hello%20${encodeURIComponent(name)}%2C%20I%20would%20like%20to%20place%20an%20order`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 py-1.5 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-colors"
            >
              <MessageCircle size={11} /> WhatsApp
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
