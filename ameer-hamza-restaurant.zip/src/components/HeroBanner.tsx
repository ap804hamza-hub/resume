import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Phone, ShieldCheck, Clock, MapPin, MessageCircle } from 'lucide-react';
import { heroImages } from '../data/restaurantData.ts';

interface HeroBannerProps {
  brandName: string;
  onOrderNow: () => void;
  onExploreVillage: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  brandName,
  onOrderNow,
  onExploreVillage,
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const totalSlides = 3;
  const primaryPhone = "03170434287";
  const formattedPhone = "0317 0434287";

  // Autoplay carousel every 7 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % totalSlides);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative w-full overflow-hidden bg-white text-white select-none">
      {/* SLIDE 1: Iconic Lahore Free Delivery Banner (Recreated in bold red, white frame) */}
      <div
        className={`relative w-full min-h-[580px] lg:min-h-[640px] flex flex-col justify-between transition-opacity duration-700 ${
          currentSlide === 0 ? 'block opacity-100' : 'hidden opacity-0'
        }`}
        style={{
          background: 'radial-gradient(ellipse at 70% 50%, #d8161f 0%, #a40e15 45%, #6a070c 80%, #200204 100%)',
        }}
      >
        {/* Speed lines & ambient glow overlay */}
        <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:24px_24px]" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-transparent to-black/30 pointer-events-none" />

        {/* Content container */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-10 pb-8 flex-1 flex flex-col lg:flex-row items-center justify-between gap-8 z-10">
          {/* Left Column: Bold Typography Matching Screenshot */}
          <div className="w-full lg:w-1/2 flex flex-col items-start space-y-3 md:space-y-4 pt-4 lg:pt-0">
            {/* Main Headline */}
            <div className="space-y-0.5">
              <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black font-display tracking-tight text-white uppercase leading-[0.95] drop-shadow-md">
                FREE DELIVERY
              </h1>
              <h2 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black font-display tracking-tight uppercase leading-[0.95]">
                <span className="text-white">ALL OVER </span>
                <span className="text-[#ffd200] drop-shadow-[0_2px_12px_rgba(255,210,0,0.4)]">
                  LAHORE
                </span>
              </h2>
            </div>

            {/* Subtitle */}
            <p className="text-white/95 font-extrabold tracking-[0.25em] text-sm sm:text-xl md:text-2xl uppercase pt-1">
              ANYTIME, ANYWHERE!
            </p>

            {/* ORDER NOW Button */}
            <div className="pt-4 sm:pt-6 flex flex-wrap items-center gap-4">
              <button
                onClick={onOrderNow}
                className="inline-flex items-center justify-center px-8 sm:px-10 py-3 sm:py-3.5 rounded-full border-2 border-white text-white font-black tracking-widest text-base sm:text-lg uppercase hover:bg-white hover:text-[#d8161f] active:scale-95 transition-all duration-200 shadow-xl shadow-red-950/40"
              >
                ORDER NOW
              </button>
              <a
                href={`tel:${primaryPhone}`}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-white text-zinc-950 font-bold text-sm hover:bg-zinc-100 transition-colors shadow-lg"
              >
                <Phone size={15} className="text-[#e21b22]" />
                <span>Call {formattedPhone}</span>
              </a>
            </div>

            {/* Trust highlights */}
            <div className="pt-4 flex flex-wrap items-center gap-4 text-xs sm:text-sm text-white/90">
              <span className="flex items-center gap-1.5 bg-black/40 px-3 py-1 rounded-full border border-white/10">
                <Clock size={14} className="text-[#ffd200]" /> 30-45 Mins Fast Delivery
              </span>
              <span className="flex items-center gap-1.5 bg-black/40 px-3 py-1 rounded-full border border-white/10">
                <ShieldCheck size={14} className="text-[#ffd200]" /> Fresh & Hot
              </span>
              <span className="flex items-center gap-1.5 bg-black/40 px-3 py-1 rounded-full border border-white/10">
                <MapPin size={14} className="text-[#ffd200]" /> All Lahore Sectors
              </span>
            </div>
          </div>

          {/* Right Column: Delivery Rider with Ameer Hamza delivery backpack */}
          <div className="w-full lg:w-1/2 flex items-center justify-center relative">
            <div className="relative w-full max-w-[540px] aspect-[16/9] lg:aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl border border-white/20 group">
              <img
                src={heroImages.rider}
                alt={`${brandName} delivery rider in Lahore`}
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />

              {/* Insulated Branded Delivery Box Badge Overlay */}
              <div className="absolute top-4 right-4 sm:top-6 sm:right-6 bg-emerald-700/95 text-white p-3 sm:p-4 rounded-xl shadow-2xl border-2 border-white/80 max-w-[190px] sm:max-w-[210px] backdrop-blur-sm">
                <div className="text-center space-y-1">
                  <div className="bg-white text-black py-1 px-2 rounded font-brand font-black text-xs sm:text-sm tracking-tight truncate">
                    {brandName}
                  </div>
                  <div className="text-[10px] sm:text-xs font-black tracking-widest text-amber-300 uppercase">
                    FREE DELIVERY
                  </div>
                  <div className="text-xs sm:text-sm font-black tracking-wider bg-black/50 py-0.5 rounded text-white font-mono">
                    {formattedPhone}
                  </div>
                </div>
              </div>

              {/* Speed flare indicator */}
              <div className="absolute bottom-3 left-3 bg-black/70 backdrop-blur-md px-3 py-1 rounded-md text-[11px] font-medium text-white border border-white/10">
                ⚡ Express Delivery Fleet
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Banner Strip with Updated 03170434287 phone number */}
        <div className="relative w-full bg-black/90 backdrop-blur-md border-t border-white/15 px-4 sm:px-6 lg:px-8 py-3.5 z-20">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-white">
            {/* Hotline numbers featuring 03170434287 */}
            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm md:text-base font-extrabold tracking-wider">
              <Phone size={16} className="text-[#ffd200]" />
              <span className="uppercase text-zinc-300">FOR DELIVERY:</span>
              <a
                href={`tel:${primaryPhone}`}
                className="text-[#ffd200] hover:underline font-mono"
              >
                {formattedPhone}
              </a>
              <span className="text-zinc-600">|</span>
              <a
                href={`https://wa.me/92${primaryPhone.slice(1)}`}
                target="_blank"
                rel="noreferrer"
                className="text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1 font-mono text-xs sm:text-sm"
              >
                <MessageCircle size={14} /> WhatsApp {formattedPhone}
              </a>
            </div>

            {/* Carousel navigation indicators */}
            <div className="flex items-center gap-2">
              {[0, 1, 2].map((idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentSlide(idx)}
                  className={`h-1.5 transition-all rounded-full ${
                    currentSlide === idx ? 'w-8 bg-[#ffd200]' : 'w-4 bg-white/40 hover:bg-white/70'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>

            {/* App Store / Google Play badges */}
            <div className="flex items-center gap-2">
              <span className="text-[11px] sm:text-xs font-black tracking-wider text-zinc-200 uppercase">
                DOWNLOAD THE APP NOW!
              </span>
              <div className="flex items-center gap-1.5">
                <a
                  href="#download-app"
                  className="bg-black hover:bg-zinc-900 border border-white/30 rounded-md px-2.5 py-1 text-[10px] flex items-center gap-1 transition-colors"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 1.01-2.87-.9.04-2.02.6-2.67 1.36-.58.67-.99 1.74-.93 2.78 1.02.08 2-.54 2.59-1.27z"/>
                  </svg>
                  <div className="text-left leading-tight">
                    <div className="text-[8px] text-zinc-400">Download on</div>
                    <div className="font-bold">App Store</div>
                  </div>
                </a>

                <a
                  href="#download-app"
                  className="bg-black hover:bg-zinc-900 border border-white/30 rounded-md px-2.5 py-1 text-[10px] flex items-center gap-1 transition-colors"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M3,20.5V3.5C3,2.91 3.34,2.39 3.84,2.15L13.69,12L3.84,21.85C3.34,21.6 3,21.09 3,20.5M16.81,15.12L6.05,21.34L14.54,12.85L16.81,15.12M20.16,10.81C20.5,11.08 20.75,11.5 20.75,12C20.75,12.5 20.53,12.9 20.18,13.18L17.89,14.5L15.39,12L17.89,9.5L20.16,10.81M6.05,2.66L16.81,8.88L14.54,11.15L6.05,2.66Z"/>
                  </svg>
                  <div className="text-left leading-tight">
                    <div className="text-[8px] text-zinc-400">GET IT ON</div>
                    <div className="font-bold">Google Play</div>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SLIDE 2: Grand Village Buffet */}
      <div
        className={`relative w-full min-h-[580px] lg:min-h-[640px] flex flex-col justify-between transition-opacity duration-700 ${
          currentSlide === 1 ? 'block opacity-100' : 'hidden opacity-0'
        }`}
        style={{
          background: 'radial-gradient(ellipse at 30% 50%, #4a1e0b 0%, #2e1104 60%, #150601 100%)',
        }}
      >
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-10 pb-8 flex-1 flex flex-col lg:flex-row items-center justify-between gap-8 z-10">
          <div className="w-full lg:w-1/2 space-y-4">
            <span className="text-[#ffd200] font-bold text-xs uppercase tracking-[0.3em] bg-amber-950/60 px-3.5 py-1 rounded-full border border-amber-600/30">
              The Heritage Experience
            </span>
            <h2 className="text-4xl sm:text-6xl font-black font-brand uppercase text-white leading-tight">
              {brandName} Village
            </h2>
            <h3 className="text-2xl sm:text-3xl font-display text-amber-200">
              PAKISTAN’S LEGENDARY LIVE BUFFET
            </h3>
            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed max-w-xl">
              Immerse yourself in authentic rustic ambiance with 80+ live dishes, charcoal grilled kebabs, wood-fired tandoor, hand-churned kulfi, and hospitality on M.M. Alam Road Lahore.
            </p>
            <div className="pt-3 flex flex-wrap items-center gap-4">
              <button
                onClick={onExploreVillage}
                className="px-8 py-3 rounded-full bg-[#e21b22] hover:bg-[#c4121a] text-white font-bold tracking-wider text-sm uppercase shadow-xl transition-all"
              >
                View Village Buffet
              </button>
              <button
                onClick={onOrderNow}
                className="px-6 py-3 rounded-full border border-white/60 hover:bg-white hover:text-black text-white font-semibold text-sm transition-all"
              >
                Order Village Specials
              </button>
            </div>
          </div>

          <div className="w-full lg:w-1/2">
            <div className="relative aspect-[16/9] rounded-2xl overflow-hidden border border-amber-900/40 shadow-2xl">
              <img
                src={heroImages.village}
                alt={`${brandName} Village Buffet`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-5">
                <span className="text-white font-bold text-sm tracking-wide">
                  🏛️ Traditional Live Kitchens & Folk Ambience
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="w-full bg-zinc-950/90 border-t border-zinc-800 px-6 py-3 flex items-center justify-between text-xs text-zinc-400">
          <span>Village Buffet Timings: Lunch 1:00 PM – 4:00 PM | Dinner 7:30 PM – Midnight | Hotline: {formattedPhone}</span>
          <div className="flex gap-2">
            {[0, 1, 2].map((idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                className={`h-1.5 rounded-full ${
                  currentSlide === idx ? 'w-8 bg-[#ffd200]' : 'w-4 bg-zinc-700'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* SLIDE 3: Express Deals & Fast Food */}
      <div
        className={`relative w-full min-h-[580px] lg:min-h-[640px] flex flex-col justify-between transition-opacity duration-700 ${
          currentSlide === 2 ? 'block opacity-100' : 'hidden opacity-0'
        }`}
        style={{
          background: 'radial-gradient(ellipse at 50% 50%, #201305 0%, #110901 60%, #080400 100%)',
        }}
      >
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-10 pb-8 flex-1 flex flex-col lg:flex-row items-center justify-between gap-8 z-10">
          <div className="w-full lg:w-1/2 space-y-4">
            <span className="text-emerald-400 font-bold text-xs uppercase tracking-[0.3em] bg-emerald-950/60 px-3.5 py-1 rounded-full border border-emerald-700/40">
              Express Combos & Deals
            </span>
            <h2 className="text-4xl sm:text-6xl font-black font-display uppercase text-white leading-tight">
              BURGER & PIZZA BONANZA
            </h2>
            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed max-w-xl">
              Juicy smashed beef burgers, golden crispy fried chicken tenders, or cheesy stone-baked pizzas delivered blazing hot right to your doorstep in Lahore!
            </p>
            <div className="pt-3">
              <button
                onClick={onOrderNow}
                className="px-8 py-3 rounded-full bg-[#e21b22] hover:bg-[#c4121a] text-white font-black tracking-widest text-sm uppercase shadow-xl transition-all"
              >
                ORDER EXPRESS DEALS
              </button>
            </div>
          </div>

          <div className="w-full lg:w-1/2">
            <div className="relative aspect-[4/3] max-w-[480px] mx-auto rounded-2xl overflow-hidden border border-zinc-800 shadow-2xl">
              <img
                src={heroImages.fastfood}
                alt={`${brandName} Fast Food Deals`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>

        <div className="w-full bg-zinc-950/90 border-t border-zinc-800 px-6 py-3 flex items-center justify-between text-xs text-zinc-400">
          <span>Late Night Delivery active until 2:00 AM across Lahore | Call: {formattedPhone}</span>
          <div className="flex gap-2">
            {[0, 1, 2].map((idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                className={`h-1.5 rounded-full ${
                  currentSlide === idx ? 'w-8 bg-[#ffd200]' : 'w-4 bg-zinc-700'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Manual Slide Controls Left/Right */}
      <button
        onClick={() => setCurrentSlide((prev) => (prev === 0 ? totalSlides - 1 : prev - 1))}
        className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white items-center justify-center border border-white/20 transition-colors z-30"
        aria-label="Previous Slide"
      >
        <ChevronLeft size={22} />
      </button>
      <button
        onClick={() => setCurrentSlide((prev) => (prev + 1) % totalSlides)}
        className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white items-center justify-center border border-white/20 transition-colors z-30"
        aria-label="Next Slide"
      >
        <ChevronRight size={22} />
      </button>
    </div>
  );
};
