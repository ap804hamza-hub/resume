import React from 'react';

interface BrandLogoProps {
  brandName: string;
  subText?: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  darkText?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  brandName = "Ameer Hamza",
  subText = "Restaurant",
  className = "",
  size = "md",
  darkText = true,
}) => {
  const sizeClasses = {
    sm: {
      title: "text-lg md:text-xl",
      sub: "text-[10px] tracking-widest",
      line: "h-[2px] mt-0.5",
      square: "w-1.5 h-1.5",
    },
    md: {
      title: "text-2xl md:text-3xl",
      sub: "text-xs tracking-[0.25em]",
      line: "h-[3px] mt-1",
      square: "w-2 h-2",
    },
    lg: {
      title: "text-3xl md:text-4xl",
      sub: "text-sm tracking-[0.3em]",
      line: "h-[4px] mt-1.5",
      square: "w-2.5 h-2.5",
    },
    xl: {
      title: "text-4xl md:text-5xl",
      sub: "text-base tracking-[0.35em]",
      line: "h-[4px] mt-2",
      square: "w-3 h-3",
    }
  }[size];

  return (
    <div className={`inline-flex flex-col select-none group cursor-pointer ${className}`}>
      {/* Main Brand Title */}
      <div className="flex items-center">
        <span
          className={`font-black font-brand tracking-tight ${sizeClasses.title} ${
            darkText ? 'text-zinc-950' : 'text-white'
          }`}
          style={{ letterSpacing: '-0.02em' }}
        >
          {brandName}
        </span>
      </div>

      {/* Red underline with accent blocks */}
      <div className="flex items-center gap-1 w-full my-0.5">
        <div className={`bg-[#e21b22] flex-1 ${sizeClasses.line}`} />
        <div className={`bg-[#e21b22] ${sizeClasses.square} shrink-0`} />
      </div>

      {/* Subtext */}
      {subText && (
        <span
          className={`font-brand italic font-bold text-[#e21b22] ${sizeClasses.sub} uppercase`}
        >
          {subText}
        </span>
      )}
    </div>
  );
};
