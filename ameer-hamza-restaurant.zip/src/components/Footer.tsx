import React from 'react';
import { Phone, Mail, MapPin, Edit3, MessageCircle, Heart } from 'lucide-react';
import { BrandLogo } from './BrandLogo.tsx';

interface FooterProps {
  brandName: string;
  onOpenBrandModal: () => void;
  onNavigate: (sectionId: string) => void;
  onOpenFranchiseModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  brandName,
  onOpenBrandModal,
  onNavigate,
  onOpenFranchiseModal,
}) => {
  const primaryPhone = "03170434287";
  const formattedPhone = "0317 0434287";

  return (
    <footer className="bg-zinc-100 text-zinc-900 border-t border-zinc-200 pt-16 pb-12 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-zinc-200">
          {/* Brand Info & Hotline */}
          <div className="lg:col-span-4 space-y-4">
            <BrandLogo brandName={brandName} subText="Restaurant" size="md" darkText={true} />

            <p className="text-xs text-zinc-600 leading-relaxed max-w-sm mt-3">
              Pakistan’s premier food brand known for authentic culinary excellence, the legendary Village live buffet, and rapid home delivery all over Lahore.
            </p>

            <div className="pt-2 space-y-2.5 text-xs">
              <div className="flex items-center gap-2 text-zinc-800">
                <Phone size={14} className="text-[#e21b22]" />
                <span className="font-medium">Direct Delivery Hotline:</span>
                <a href={`tel:${primaryPhone}`} className="font-mono font-bold text-zinc-950 hover:text-[#e21b22]">
                  {formattedPhone}
                </a>
              </div>
              <div className="flex items-center gap-2 text-zinc-800">
                <MessageCircle size={14} className="text-emerald-600" />
                <span className="font-medium">WhatsApp Support:</span>
                <a href={`https://wa.me/92${primaryPhone.slice(1)}`} target="_blank" rel="noreferrer" className="font-mono font-bold text-emerald-700 hover:underline">
                  {formattedPhone}
                </a>
              </div>
              <div className="flex items-center gap-2 text-zinc-600">
                <MapPin size={14} className="text-[#e21b22]" />
                <span>Mall Road & Liberty Market, Lahore, Pakistan</span>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={onOpenBrandModal}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-zinc-200 text-xs text-zinc-700 hover:text-zinc-950 border border-zinc-300 transition-colors shadow-2xs"
              >
                <Edit3 size={13} className="text-[#e21b22]" />
                <span>Change Brand Name ({brandName})</span>
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-950">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs text-zinc-600">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-zinc-950 transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('menu')} className="hover:text-zinc-950 transition-colors">
                  Order Online & Menu
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-zinc-950 font-bold text-[#e21b22] transition-colors">
                  Contact Us ({formattedPhone})
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('brands')} className="hover:text-zinc-950 transition-colors">
                  Our Brands
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-zinc-950 transition-colors">
                  About Us
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('publications')} className="hover:text-zinc-950 transition-colors">
                  Publications
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('locations')} className="hover:text-zinc-950 transition-colors">
                  Lahore Branches
                </button>
              </li>
              <li>
                <button onClick={onOpenFranchiseModal} className="hover:text-zinc-950 transition-colors">
                  Get a Franchise
                </button>
              </li>
            </ul>
          </div>

          {/* Dining Divisions */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-950">
              Dining Divisions
            </h4>
            <ul className="space-y-2 text-xs text-zinc-600">
              <li>
                <strong className="text-zinc-900 block">{brandName} Restaurant</strong>
                <span className="text-[11px] text-zinc-500">Mall Road & Liberty Market Lahore</span>
              </li>
              <li>
                <strong className="text-zinc-900 block">{brandName} Village</strong>
                <span className="text-[11px] text-zinc-500">Live Cooking Grand Buffet on M.M. Alam Rd</span>
              </li>
              <li>
                <strong className="text-zinc-900 block">{brandName} Express</strong>
                <span className="text-[11px] text-zinc-500">Fast Food, Burgers & 30-Min Delivery</span>
              </li>
              <li>
                <strong className="text-zinc-900 block">{brandName} Banquets</strong>
                <span className="text-[11px] text-zinc-500">Royal Catering & Event Halls</span>
              </li>
            </ul>
          </div>

          {/* Download App */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-950">
              Download Mobile App
            </h4>
            <p className="text-xs text-zinc-600">
              Order on our iOS & Android apps for instant live order tracking & exclusive Lahore discounts.
            </p>

            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <a
                href="#app-store"
                className="bg-white hover:bg-zinc-50 border border-zinc-300 rounded-lg px-3 py-2 text-xs flex items-center gap-2 transition-colors shadow-2xs"
              >
                <svg className="w-4 h-4 fill-current text-zinc-900" viewBox="0 0 24 24">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 1.01-2.87-.9.04-2.02.6-2.67 1.36-.58.67-.99 1.74-.93 2.78 1.02.08 2-.54 2.59-1.27z"/>
                </svg>
                <div className="leading-tight">
                  <div className="text-[9px] text-zinc-500">Download on</div>
                  <div className="font-bold text-zinc-950 text-[11px]">App Store</div>
                </div>
              </a>

              <a
                href="#google-play"
                className="bg-white hover:bg-zinc-50 border border-zinc-300 rounded-lg px-3 py-2 text-xs flex items-center gap-2 transition-colors shadow-2xs"
              >
                <svg className="w-4 h-4 fill-current text-zinc-900" viewBox="0 0 24 24">
                  <path d="M3,20.5V3.5C3,2.91 3.34,2.39 3.84,2.15L13.69,12L3.84,21.85C3.34,21.6 3,21.09 3,20.5M16.81,15.12L6.05,21.34L14.54,12.85L16.81,15.12M20.16,10.81C20.5,11.08 20.75,11.5 20.75,12C20.75,12.5 20.53,12.9 20.18,13.18L17.89,14.5L15.39,12L17.89,9.5L20.16,10.81M6.05,2.66L16.81,8.88L14.54,11.15L6.05,2.66Z"/>
                </svg>
                <div className="leading-tight">
                  <div className="text-[9px] text-zinc-500">GET IT ON</div>
                  <div className="font-bold text-zinc-950 text-[11px]">Google Play</div>
                </div>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar with Ameer Hamza on Left */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-zinc-800">{brandName}</span>
            <span>·</span>
            <span>Hotline: <strong className="text-zinc-900 font-mono">{formattedPhone}</strong></span>
            <span>·</span>
            <span>© {new Date().getFullYear()} All Rights Reserved.</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-zinc-500">Privacy Policy</span>
            <span className="text-zinc-400">·</span>
            <span className="text-zinc-500">Terms of Service</span>
            <span className="text-zinc-400">·</span>
            <span className="text-zinc-500">Food Safety Standards</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
