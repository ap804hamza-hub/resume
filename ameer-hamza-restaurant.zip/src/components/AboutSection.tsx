import React from 'react';
import { Award, HeartHandshake } from 'lucide-react';
import { heroImages } from '../data/restaurantData.ts';

interface AboutSectionProps {
  brandName: string;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ brandName }) => {
  return (
    <section id="about" className="py-20 bg-white text-zinc-900 border-t border-zinc-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left: Visual montage */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden border border-zinc-200 shadow-xl bg-zinc-100">
              <img
                src={heroImages.village}
                alt={`${brandName} heritage restaurant in Lahore`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            </div>

            {/* Overlapping stat card */}
            <div className="absolute -bottom-6 -right-2 sm:right-6 bg-white border border-zinc-200 p-5 rounded-2xl shadow-xl backdrop-blur-md max-w-xs">
              <div className="text-3xl font-black font-brand text-[#e21b22]">
                40+ Years
              </div>
              <div className="text-xs text-zinc-700 font-semibold mt-1">
                Of Hospitality & Culinary Heritage in Pakistan
              </div>
            </div>
          </div>

          {/* Right: Narrative */}
          <div className="lg:col-span-6 space-y-6">
            <span className="text-[#e21b22] text-xs font-bold uppercase tracking-[0.3em] block">
              The Heritage of Hospitality
            </span>
            <h2 className="text-3xl sm:text-5xl font-black font-brand uppercase tracking-tight text-zinc-950">
              Pioneers of Dining in Pakistan
            </h2>
            <p className="text-zinc-600 text-sm sm:text-base leading-relaxed">
              Founded in Lahore, <strong className="text-zinc-950">{brandName}</strong> is widely recognized as a benchmark for culinary innovation and genuine hospitality. From humble beginnings on The Mall to pioneering the legendary Village live buffet concept, we have introduced generations of diners to world-class cuisine and authentic Pakistani feasts.
            </p>
            <p className="text-zinc-600 text-xs sm:text-sm leading-relaxed">
              Today, the {brandName} restaurant family spans premier fine dining restaurants, bustling express delivery hubs, and nationwide branches across Lahore, Islamabad, Faisalabad, and beyond.
            </p>

            {/* Key Pillars */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-zinc-200">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-50 border border-red-100 flex items-center justify-center text-[#e21b22] shrink-0">
                  <Award size={20} />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-zinc-900">Uncompromising Quality</h4>
                  <p className="text-[11px] text-zinc-500 mt-0.5">Freshly slaughtered Halal meat & whole spices.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-50 border border-red-100 flex items-center justify-center text-[#e21b22] shrink-0">
                  <HeartHandshake size={20} />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-zinc-900">Warm Hospitality</h4>
                  <p className="text-[11px] text-zinc-500 mt-0.5">Mughal-era grace and generous portions.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
