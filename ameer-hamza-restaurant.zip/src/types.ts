export interface MenuItem {
  id: string;
  name: string;
  category: 'deals' | 'karahi' | 'bbq' | 'fastfood' | 'pizza' | 'dessert';
  description: string;
  price: number;
  image: string;
  isSpicy?: boolean;
  spiceLevel?: 'Mild' | 'Medium' | 'Hot';
  serves?: string;
  badge?: string;
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
  selectedSpice?: 'Mild' | 'Medium' | 'Hot';
  specialNote?: string;
}

export interface BrandConcept {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  location: string;
  features: string[];
  image: string;
  tag: string;
}

export interface BranchLocation {
  id: string;
  name: string;
  city: string;
  address: string;
  timing: string;
  phone: string;
  type: string;
}

export interface Publication {
  id: string;
  title: string;
  author: string;
  year: string;
  description: string;
  highlights: string[];
  badge: string;
}
